import { NextRequest, NextResponse } from 'next/server';
import { ensureFyList, getUnits } from '@/lib/stock-zoho';
import { fyStartYearOf } from '@/lib/stock-period';
import { todayIST } from '@/lib/stock-service';

export const dynamic = 'force-dynamic';
export const maxDuration = 300;

/**
 * Keeps the Stock Statement's year list and unit list ready each morning (vercel.json: 07:45 India time, after the
 * Debtors / Creditors refresh has finished, so the two never read Zoho at the same time). The Stock Statement itself
 * is read live whenever a period is opened; this only means nobody has to wait for the list.
 *
 *   ?reset=1   throw the year's list away and rebuild it from every month-end (use after a big correction in Zoho)
 *
 * Protected by CRON_SECRET exactly like the 7 AM refresh. If a rebuild runs out of time it says so: call it again
 * and it carries on where it stopped.
 */
export async function GET(req: NextRequest) {
  const secret = process.env.CRON_SECRET;
  if (secret && req.headers.get('authorization') !== `Bearer ${secret}`) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
  try {
    const today = todayIST();
    const fy = fyStartYearOf(today);
    const reset = req.nextUrl.searchParams.get('reset') === '1';
    const progress = await ensureFyList(fy, today, 230_000, { reset });
    const units = await getUnits({ force: true });
    return NextResponse.json({
      ok: true,
      financialYearStartingIn: fy,
      months: { done: progress.done, total: progress.total, complete: progress.complete, readThisRun: progress.builtNow, busy: progress.busy },
      productsOnTheList: Object.keys(progress.record.names).length,
      itemUnitsKnown: Object.keys(units.units).length,
      note: progress.complete ? 'The list is complete.' : 'Not finished: call this again to carry on.',
    });
  } catch (err) {
    console.error('Stock cron failed:', err);
    return NextResponse.json({ error: err instanceof Error ? err.message : 'Unknown error' }, { status: 500 });
  }
}
