import { NextRequest, NextResponse } from 'next/server';
import { getStock, todayIST } from '@/lib/stock-service';
import { clampStockRange } from '@/lib/stock-period';

export const dynamic = 'force-dynamic';
// The very first call of a financial year reads one report per month from Zoho; it hands back "still preparing"
// well before this limit and the page asks again, so this is only a safety net.
export const maxDuration = 300;

/**
 * The Stock Statement for a period, read LIVE from Zoho's Stock Summary report.
 *   /api/stock?from=2026-09-01&to=2026-09-30        (&fresh=1 skips the few minutes' memory)
 * Answers { building: true, progress } while the financial year's list of products is still being prepared.
 */
export async function GET(req: NextRequest) {
  try {
    const today = todayIST();
    const sp = req.nextUrl.searchParams;
    const range = clampStockRange(sp.get('from'), sp.get('to'), today);
    const res = await getStock(range.from, range.to, { fresh: sp.get('fresh') === '1', today });
    if (res.building) return NextResponse.json({ building: true, progress: res.progress, busy: res.busy });
    return NextResponse.json({ ...res.data, rangeAdjusted: range.changed });
  } catch (err) {
    console.error('Stock statement failed:', err);
    return NextResponse.json({ error: err instanceof Error ? err.message : 'Unknown error reading the stock statement' }, { status: 500 });
  }
}
