// Reading the Stock Summary from Zoho Books, and keeping the financial year's list of products that are shown
// separately. Server only.
//
// The report is Zoho's own "Stock Summary" (entity inventory_stock_details). Unlike the Debtors / Creditors tabs this is
// read LIVE every time a period is opened (a few minutes' memory at most, see stock-service.ts): nothing here is
// frozen, so the tab never drifts from what Zoho itself shows.
//
// The financial year's list (rule 5 of stock-calculator.ts) is built from the month-end closings of the year so
// far, one Zoho read per month, and is kept in Redis. Only the NAMES are kept, never any stock figure.

import { Redis } from '@upstash/redis';
import { zohoTry } from './zoho-client';
import { qualifyingProducts, type StockRow } from './stock-calculator';
import { fyEndISO, fyStartISO } from './stock-period';

// ------------------------------------------------------------------------------------------------ storage

let redisClient: Redis | null = null;
function getRedis(): Redis | null {
  const url = process.env.UPSTASH_REDIS_REST_URL;
  const token = process.env.UPSTASH_REDIS_REST_TOKEN;
  if (!url || !token) return null;
  if (!redisClient) redisClient = new Redis({ url, token });
  return redisClient;
}
// Without Redis (a local run with no Upstash) everything is kept in memory for as long as the server runs.
const mem = new Map<string, unknown>();
const memLocks = new Map<string, number>();

async function kvGet<T>(key: string): Promise<T | null> {
  const r = getRedis();
  if (!r) return (mem.get(key) as T | undefined) ?? null;
  try {
    return (await r.get<T>(key)) ?? null;
  } catch (e) {
    console.error('Redis read failed (stock):', e);
    return (mem.get(key) as T | undefined) ?? null;
  }
}
async function kvSet(key: string, value: unknown): Promise<void> {
  mem.set(key, value);
  const r = getRedis();
  if (!r) return;
  try {
    await r.set(key, JSON.stringify(value));
  } catch (e) {
    console.error('Redis write failed (stock):', e);
  }
}
async function acquireLock(key: string, seconds: number): Promise<boolean> {
  const r = getRedis();
  if (!r) {
    if ((memLocks.get(key) ?? 0) > Date.now()) return false;
    memLocks.set(key, Date.now() + seconds * 1000);
    return true;
  }
  try {
    return (await r.set(key, new Date().toISOString(), { nx: true, ex: seconds })) === 'OK';
  } catch {
    return true; // Redis down: carry on rather than block
  }
}
async function releaseLock(key: string): Promise<void> {
  memLocks.delete(key);
  const r = getRedis();
  if (!r) return;
  try {
    await r.del(key);
  } catch {
    /* it expires by itself */
  }
}

// ------------------------------------------------------------------------------------------------ the report

type Raw = Record<string, unknown>;
const num = (v: unknown): number => {
  if (typeof v === 'number') return Number.isFinite(v) ? v : 0;
  const n = Number(String(v ?? '').replace(/,/g, ''));
  return Number.isFinite(n) ? n : 0;
};

/** Every object in the response that looks like a stock line, however deeply the report nests it. */
function findRows(body: unknown): Raw[] {
  const out: Raw[] = [];
  const walk = (v: unknown, depth: number) => {
    if (depth > 6 || v === null || typeof v !== 'object') return;
    if (Array.isArray(v)) {
      for (const x of v) walk(x, depth + 1);
      return;
    }
    const o = v as Raw;
    if ('item_name' in o && ('closing_stock' in o || 'closing_stock_value' in o || 'opening_stock' in o)) {
      out.push(o);
      return;
    }
    for (const x of Object.values(o)) walk(x, depth + 1);
  };
  walk(body, 0);
  return out;
}
const hasMore = (body: Raw): boolean => Boolean((body.page_context as Raw | undefined)?.has_more_page);

// The path Zoho answers on for this account was found on 12 Oct 2026 (the report's entity name without underscores).
let workingPath: string | null = null;
const reportPaths = () => [process.env.ZOHO_REPORT_PATH_STOCK, 'inventorystockdetails', 'inventory_stock_details'].filter((p): p is string => Boolean(p));

/**
 * One read of Zoho's Stock Summary for From..To: every item (the report lists items with no stock too), with
 * Opening Stock, Quantity In, Quantity Out, Closing Stock and Closing Stock Amount. Pages are read three at a time.
 */
export async function pullStockReport(from: string, to: string): Promise<{ rows: StockRow[]; pages: number; ms: number }> {
  const t0 = Date.now();
  const params = (page: number) => ({
    filter_by: 'TransactionDate.CustomDate',
    from_date: from,
    to_date: to,
    per_page: 500,
    response_option: 1,
    usestate: 'false',
    ...(page > 1 ? { page } : {}),
  });

  let first: Raw | null = null;
  let path = '';
  let lastError = '';
  for (const p of workingPath ? [workingPath] : reportPaths()) {
    const res = await zohoTry(`/reports/${p}`, params(1));
    if (res.ok) {
      first = res.body;
      path = p;
      workingPath = p;
      break;
    }
    lastError = `HTTP ${res.status}: ${res.error}`;
    if (res.status !== 404) break; // 404 is only a wrong path name; anything else is a real answer from Zoho
  }
  if (!first) {
    workingPath = null;
    throw new Error(`Zoho would not give the Stock Summary report (${lastError}). Check that the Zoho credentials may read reports.`);
  }

  const raw: Raw[] = [...findRows(first)];
  let pages = 1;
  let more = hasMore(first);
  while (more && pages < 30) {
    const batch = [pages + 1, pages + 2, pages + 3];
    const results = await Promise.all(batch.map((p) => zohoTry(`/reports/${path}`, params(p))));
    let stop = false;
    for (let i = 0; i < results.length; i++) {
      const r = results[i];
      if (!r.ok) throw new Error(`Zoho stopped part-way through the Stock Summary (page ${batch[i]}, HTTP ${r.status}): ${r.error}`);
      const rs = findRows(r.body);
      raw.push(...rs);
      if (rs.length === 0 || !hasMore(r.body)) {
        stop = true;
        break;
      }
    }
    pages += batch.length;
    more = !stop;
  }

  // one row per item; if Zoho ever repeated a row across two pages it must not be counted twice
  const byId = new Map<string, StockRow>();
  for (const r of raw) {
    const itemId = String(r.item_id ?? '') || `name:${String(r.item_name)}`;
    byId.set(itemId, {
      itemId,
      name: String(r.item_name ?? ''),
      opening: num(r.opening_stock),
      qtyIn: num(r.quantity_in),
      qtyOut: num(r.quantity_out),
      closing: num(r.closing_stock),
      closingValue: num(r.closing_stock_value),
    });
  }
  if (byId.size === 0) throw new Error(`Zoho's Stock Summary came back with no items for ${from} to ${to}.`);
  return { rows: [...byId.values()], pages, ms: Date.now() - t0 };
}

// ------------------------------------------------------------------------------------------------ units

const UNITS_KEY = 'rpel-apar:stock:units';
interface UnitCache {
  fetchedAt: string;
  units: Record<string, string>;
}
let unitMemo: UnitCache | null = null;

/** item id -> unit ("Nos", "Mtr"...). The Stock Summary does not carry it, the item list does. Kept for a day. */
export async function getUnits(opts: { force?: boolean; maxAgeMs?: number } = {}): Promise<UnitCache> {
  const maxAge = opts.maxAgeMs ?? 24 * 3_600_000;
  const fresh = (c: UnitCache | null) => c !== null && Date.now() - new Date(c.fetchedAt).getTime() < maxAge;
  if (!opts.force && fresh(unitMemo)) return unitMemo as UnitCache;
  if (!opts.force) {
    const stored = await kvGet<UnitCache>(UNITS_KEY);
    if (stored && fresh(stored)) {
      unitMemo = stored;
      return stored;
    }
  }
  const units: Record<string, string> = {};
  let ok = true;
  for (let page = 1; page <= 40; page++) {
    const res = await zohoTry('/items', { per_page: 200, page, filter_by: 'Status.All' });
    if (!res.ok) {
      ok = false;
      console.error(`Item list page ${page} failed (HTTP ${res.status}): ${res.error}`);
      break;
    }
    for (const it of (Array.isArray(res.body.items) ? res.body.items : []) as Raw[]) {
      if (it.item_id !== undefined) units[String(it.item_id)] = String(it.unit ?? '');
    }
    if (!hasMore(res.body)) break;
  }
  if (!ok && Object.keys(units).length === 0) {
    // could not read the list at all: a stale copy is better than none
    const stale = unitMemo ?? (await kvGet<UnitCache>(UNITS_KEY));
    return stale ?? { fetchedAt: new Date(0).toISOString(), units: {} };
  }
  const cache: UnitCache = { fetchedAt: new Date().toISOString(), units };
  if (ok) {
    unitMemo = cache;
    await kvSet(UNITS_KEY, cache);
  }
  return cache;
}

// ------------------------------------------------------------------------------------------------ the year's list

export interface FyListRecord {
  /** the calendar year the financial year starts in (2026 = FY27) */
  fy: number;
  /** products shown separately all year: product key -> its name and the first month-end it went over Rs 5,00,000 */
  names: Record<string, { display: string; first: string }>;
  /** month ("2026-09") -> the date its closing was read up to, and when */
  checkpoints: Record<string, { to: string; builtAt: string }>;
  updatedAt: string;
}

const fyKey = (fy: number) => `rpel-apar:stock:fylist:${fy}`;
const fyLockKey = (fy: number) => `rpel-apar:stock:fylist-lock:${fy}`;
const emptyRecord = (fy: number): FyListRecord => ({ fy, names: {}, checkpoints: {}, updatedAt: new Date().toISOString() });

export async function readFyList(fy: number): Promise<FyListRecord> {
  return (await kvGet<FyListRecord>(fyKey(fy))) ?? emptyRecord(fy);
}
async function writeFyList(rec: FyListRecord): Promise<void> {
  rec.updatedAt = new Date().toISOString();
  await kvSet(fyKey(rec.fy), rec);
}

/** The months of a financial year that have started, each as the dates its closing is read up to. */
export function fyMonths(fy: number, today: string): { ym: string; from: string; to: string }[] {
  const out: { ym: string; from: string; to: string }[] = [];
  const start = fyStartISO(fy);
  if (start > today) return out;
  const end = fyEndISO(fy);
  for (let i = 0; i < 12; i++) {
    const y = fy + Math.floor((3 + i) / 12);
    const m0 = (3 + i) % 12;
    const from = `${y}-${String(m0 + 1).padStart(2, '0')}-01`;
    if (from > today || from > end) break;
    const last = new Date(Date.UTC(y, m0 + 1, 0)).getUTCDate();
    const monthEnd = `${y}-${String(m0 + 1).padStart(2, '0')}-${String(last).padStart(2, '0')}`;
    out.push({ ym: from.slice(0, 7), from, to: monthEnd > today ? today : monthEnd });
  }
  return out;
}

export interface FyProgress {
  record: FyListRecord;
  done: number;
  total: number;
  complete: boolean;
  /** another request is already building it */
  busy: boolean;
  builtNow: number;
}

/**
 * Makes sure the year's list covers every month-end so far (and today). A month is read from Zoho once, when it
 * has no entry yet; the running month is read again each new day. Reads stop when `budgetMs` is used up and the
 * work already done is kept, so a long first build simply carries on in the next call.
 */
export async function ensureFyList(fy: number, today: string, budgetMs: number, opts: { reset?: boolean } = {}): Promise<FyProgress> {
  const months = fyMonths(fy, today);
  let record = opts.reset ? emptyRecord(fy) : await readFyList(fy);
  const needs = (m: { ym: string; to: string }) => record.checkpoints[m.ym]?.to !== m.to;
  const progress = (builtNow: number, busy: boolean): FyProgress => {
    const left = months.filter(needs).length;
    return { record, done: months.length - left, total: months.length, complete: left === 0, busy, builtNow };
  };
  if (!opts.reset && months.filter(needs).length === 0) return progress(0, false);

  if (!(await acquireLock(fyLockKey(fy), Math.ceil(budgetMs / 1000) + 120))) return progress(0, true);
  try {
    if (opts.reset) await writeFyList(record);
    else record = await readFyList(fy); // another request may have finished some months while this one waited
    const t0 = Date.now();
    let built = 0;
    let lastMs = 0;
    for (const m of months.filter(needs)) {
      if (built > 0 && Date.now() - t0 + lastMs * 1.3 > budgetMs) break;
      const t1 = Date.now();
      const pulled = await pullStockReport(m.from, m.to);
      for (const q of qualifyingProducts(pulled.rows)) {
        if (!record.names[q.key]) record.names[q.key] = { display: q.name, first: m.to };
      }
      record.checkpoints[m.ym] = { to: m.to, builtAt: new Date().toISOString() };
      await writeFyList(record); // saved month by month: a stop half-way loses nothing
      built += 1;
      lastMs = Date.now() - t1;
    }
    return progress(built, false);
  } finally {
    await releaseLock(fyLockKey(fy));
  }
}

/** Products found over Rs 5,00,000 in a period being opened that the list did not have yet (a month restated since it was read). */
export async function addToFyList(fy: number, items: { key: string; name: string }[], date: string): Promise<FyListRecord> {
  const record = await readFyList(fy);
  let changed = false;
  for (const it of items) {
    if (!record.names[it.key]) {
      record.names[it.key] = { display: it.name, first: date };
      changed = true;
    }
  }
  if (changed) await writeFyList(record);
  return record;
}
