// One place that answers "the Stock Statement for From..To", for the page and for the Excel download. Server only.

import { buildStatement, qualifyingProducts, type StockApiData, type StockRow } from './stock-calculator';
import { addToFyList, ensureFyList, getUnits, pullStockReport } from './stock-zoho';
import { fyLabel, fyStartYearOf } from './stock-period';
import { isMockMode } from './mock-data';
import { mockStockRows, mockUnits } from './stock-mock';

/** Today's date in India (the server itself runs in UTC, which is still "yesterday" until 5:30 AM IST). */
export function todayIST(): string {
  return new Date(Date.now() + 330 * 60_000).toISOString().slice(0, 10);
}

export type StockResult =
  | { building: true; progress: { done: number; total: number }; busy: boolean }
  | { building: false; data: StockApiData };

// A finished answer is kept for a few minutes so that clicking between periods, or the Excel download that follows
// a look at the page, does not read Zoho again. "Refresh" on the page skips it.
const ANSWER_TTL_MS = 5 * 60_000;
const answers = new Map<string, { at: number; listAt: string; data: StockApiData }>();

/** How long one request may spend building the year's list before it hands back "still preparing" (the page asks again). */
const LIST_BUDGET_MS = Number(process.env.STOCK_LIST_BUDGET_MS ?? 40_000);

export async function getStock(from: string, to: string, opts: { fresh?: boolean; today: string }): Promise<StockResult> {
  const fy = fyStartYearOf(to);

  if (isMockMode()) {
    const rows = mockStockRows();
    const keys = new Set(qualifyingProducts(rows).map((q) => q.key));
    const units = mockUnits();
    const stmt = buildStatement(rows, keys, (id) => units[id] ?? '');
    return {
      building: false,
      data: { ...stmt, from, to, fy: fyLabel(fy), listCount: keys.size, pulledAt: new Date().toISOString(), cached: false, mock: true },
    };
  }

  // 1. The year's list of separately shown products must cover every month-end so far.
  const list = await ensureFyList(fy, opts.today, LIST_BUDGET_MS);
  if (!list.complete) return { building: true, progress: { done: list.done, total: list.total }, busy: list.busy };

  const cacheKey = `${from}..${to}`;
  const hit = answers.get(cacheKey);
  if (!opts.fresh && hit && Date.now() - hit.at < ANSWER_TTL_MS && hit.listAt === list.record.updatedAt) {
    return { building: false, data: { ...hit.data, cached: true } };
  }

  // 2. Zoho's report for the period, as it stands right now.
  const pulled = await pullStockReport(from, to);
  const rows: StockRow[] = pulled.rows;

  // 3. Anything over Rs 5,00,000 in THIS period that the list does not know yet (e.g. a month restated since it was read) joins the list,
  //    so that nothing of that size can hide in the last line.
  const keys = new Set(Object.keys(list.record.names));
  const missing = qualifyingProducts(rows).filter((q) => !keys.has(q.key));
  let listAt = list.record.updatedAt;
  if (missing.length) {
    const updated = await addToFyList(fy, missing, to);
    listAt = updated.updatedAt;
    for (const m of missing) keys.add(m.key);
  }

  // 4. Units (the report does not carry them). Read from the item list once a day; read again if a shown product has none.
  let units = await getUnits();
  const build = () => buildStatement(rows, keys, (id) => units.units[id] ?? '');
  let stmt = build();
  if (stmt.lines.some((l) => !l.unit) && Date.now() - new Date(units.fetchedAt).getTime() > 30 * 60_000) {
    units = await getUnits({ force: true });
    stmt = build();
  }

  const data: StockApiData = {
    ...stmt,
    from,
    to,
    fy: fyLabel(fy),
    listCount: keys.size,
    pulledAt: new Date().toISOString(),
    cached: false,
    pages: pulled.pages,
    ms: pulled.ms,
  };
  if (answers.size >= 20) {
    const oldest = answers.keys().next().value;
    if (oldest !== undefined) answers.delete(oldest);
  }
  answers.set(cacheKey, { at: Date.now(), listAt, data });
  return { building: false, data };
}
