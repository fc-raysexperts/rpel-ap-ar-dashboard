// Offline self-test for the Stock Statement tab (no credentials, no network). Run: npx tsx scripts/selftest-stock.ts
//
// Checks the rules in lib/stock-calculator.ts on the examples Jatin gave (13 Oct 2026) and on random data, and
// the date rules in lib/stock-period.ts.

import { buildStatement, qualifyingProducts, itemKey, LIST_THRESHOLD, OTHER_LABEL, type StockRow } from '../lib/stock-calculator';
import {
  STOCK_FIRST_DATE, clampStockRange, defaultStockRange, fyStartYearOf, stockMonthOptions, stockQuarterOptions, stockYearOptions,
} from '../lib/stock-period';

let failures = 0;
function check(label: string, ok: boolean, extra = '') {
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${label}${extra ? '  -> ' + extra : ''}`);
  if (!ok) failures += 1;
}
const near = (a: number, b: number, tol = 0.005) => Math.abs(a - b) <= tol;

let n = 0;
const row = (name: string, opening: number, qtyIn: number, qtyOut: number, closing: number, closingValue: number): StockRow => ({
  itemId: `id${++n}`, name, opening, qtyIn, qtyOut, closing, closingValue,
});
const none = new Set<string>();

// ---------------------------------------------------------------- the four Sept 2026 items from the brief
console.log('--- Point 3: negative stock goes into the last line; amount rule ---');
{
  const rows = [
    row('FUSE', -3, 0, 0, -3, -3),
    row('PG Clamp', -3, 0, 3, -6, 1680),
    row('Shock Treatment Chart', -9, 0, 0, -9, 0),
    row('LCL Fan Black', -11, 0, 0, -11, 21800),
  ];
  const s = buildStatement(rows, new Set(rows.map((r) => itemKey(r.name)))); // even if they were on the list
  check('all four are in the last line, none shown separately', s.lines.length === 0 && s.other.name === OTHER_LABEL && s.other.itemCount === 4 && s.other.negativeCount === 4);
  check('Opening Stock total = -26 (negatives added as they are)', s.other.opening === -26 && s.total.opening === -26);
  check('Quantity Out = 3, Closing Stock = -29', s.other.qtyOut === 3 && s.other.closing === -29);
  check('Closing Stock Amount = -3 (FUSE kept, PG Clamp and LCL Fan left out, Shock chart is 0)', s.other.closingValue === -3 && s.total.closingValue === -3, String(s.total.closingValue));
  check('Zoho would add 23,477 (-3 + 1,680 + 0 + 21,800)', s.zoho.closingValue === 23477, String(s.zoho.closingValue));
  check('the difference, -23,480, is exactly the two left-out amounts', s.valueDifference === -23480, String(s.valueDifference));
  check('only PG Clamp and LCL Fan Black are listed as adjusted', s.adjustments.length === 2 && s.adjustments.every((a) => a.reason === 'negative-stock-value-excluded'), s.adjustments.map((a) => a.name).join(', '));
  check('quantities tie to Zoho', s.quantitiesTie);
}

// ---------------------------------------------------------------- point 5: old + new SKU clubbed
console.log('--- Point 5: old and new SKU of one item are clubbed ---');
{
  // the two items in the Zoho screenshot (Sept 2026): +928 / -928 and +359 / -359, the amount sits on the positive SKU
  const rows = [
    row('1C X 240 Sqmm cable', 928, 0, 0, 928, 295104),
    row('1C X 240 Sqmm cable', -928, 0, 0, -928, 0),
    row('4C X 16 Sqmm AI Arm Cable', 359, 0, 0, 359, 37695),
    row('4C X 16 Sqmm AI Arm Cable', -359, 0, 0, -359, 0),
  ];
  const s = buildStatement(rows, none);
  check('each pair adds up to nil stock, so no negative stock is left', s.other.negativeCount === 0 && s.other.opening === 0 && s.other.closing === 0);
  check('...and a nil stock has a nil amount (Zoho still shows 2,95,104 + 37,695)', s.other.closingValue === 0 && s.zoho.closingValue === 332799, `${s.other.closingValue} vs Zoho ${s.zoho.closingValue}`);
  check('both pairs are listed as adjusted: amount dropped', s.adjustments.length === 2 && s.adjustments.every((a) => a.reason === 'zero-stock-value-dropped'));
  check('name clubbing ignores capitals and extra spaces', itemKey('  Solar  MODULE ') === itemKey('solar module'));
}
{
  // net stock stays positive: stock x rate of the SKU that holds it (Aug 2026 Solar Module)
  const rows = [
    row('Solar Module', -720, 720, 0, 0, 0),
    row('Solar Module', 863, 3124, 3844, 143, 1350724),
  ];
  const s = buildStatement(rows, new Set([itemKey('Solar Module')]));
  const l = s.lines[0];
  check('positive net: shown separately when on the list', s.lines.length === 1 && l.name === 'Solar Module');
  check('net Opening 143, In 3,844, Out 3,844, Closing 143', l.opening === 143 && l.qtyIn === 3844 && l.qtyOut === 3844 && l.closing === 143);
  check('amount = 143 x (1,350,724 / 143) = 1,350,724', near(l.closingValue, 1350724), String(l.closingValue));
}
{
  // a negative SKU that carries an amount, net stock still positive: the amount follows the stock, not the negative amount
  const rows = [
    row('Battery Pack', -3, 0, 0, -3, -300000),
    row('Battery Pack', 11, 7, 11, 7, 700000),
  ];
  const s = buildStatement(rows, new Set([itemKey('Battery Pack')]));
  check('net stock 4 x rate 100,000 = 400,000', near(s.total.closingValue, 400000), String(s.total.closingValue));
  check('net opening 8 is positive so the pack stays a separate line', s.lines.length === 1 && s.lines[0].opening === 8 && s.lines[0].closing === 4);
  check('here stock x rate happens to equal Zoho\'s sum, so nothing is listed as adjusted', s.adjustments.length === 0);
}
{
  const rows = [
    row('Battery Pack', -3, 0, 0, -3, -9000000),
    row('Battery Pack', 11, 7, 11, 7, 27000000),
  ];
  const s = buildStatement(rows, new Set([itemKey('Battery Pack')]));
  check('stock x rate replaces the sum when a negative SKU would drag the amount down (4 x 3,857,142.86)', near(s.total.closingValue, 4 * (27000000 / 7), 0.01) && s.adjustments[0]?.reason === 'clubbed-stock-times-rate', String(s.total.closingValue));
}
{
  // clubbing leaves NEGATIVE net stock: point 3 applies to the clubbed product
  const rows = [
    row('Cable X', 10, 0, 0, 10, 5000),
    row('Cable X', -25, 0, 0, -25, -20),
  ];
  const s = buildStatement(rows, none);
  check('net stock -15 -> last line, quantities as they are', s.other.closing === -15 && s.other.opening === -15 && s.other.negativeCount === 1);
  check('its amount (Zoho: 4,980 positive) is left out', s.other.closingValue === 0 && s.adjustments[0]?.reason === 'negative-stock-value-excluded', String(s.other.closingValue));
}

// ---------------------------------------------------------------- point 3/4: negative OPENING with positive closing
console.log('--- a listed item with negative net Opening goes to the last line for that period ---');
{
  const rows = [
    row('Solar Module', -720, 0, 0, -720, -6420600),
    row('Solar Module', 593, 270, 0, 863, 7719972),
  ];
  const s = buildStatement(rows, new Set([itemKey('Solar Module')]));
  check('net Opening -127: in the last line although it is on the list', s.lines.length === 0 && s.other.opening === -127 && s.other.closing === 143 && s.other.negativeCount === 1);
  check('closing 143 x rate 7,719,972/863 is its amount', near(s.other.closingValue, 143 * (7719972 / 863), 0.01), String(s.other.closingValue));
}

// ---------------------------------------------------------------- point 4: which items are shown separately
console.log('--- the Rs 5,00,000 rule ---');
{
  const rows = [row('At the line', 10, 0, 0, 10, 500000), row('A paisa over', 10, 0, 0, 10, 500000.01), row('Small', 3, 0, 0, 3, 100)];
  const q = qualifyingProducts(rows).map((x) => x.name);
  check('exactly Rs 5,00,000 does not qualify, 5,00,000.01 does', q.length === 1 && q[0] === 'A paisa over' && LIST_THRESHOLD === 500000, q.join(','));
  const s = buildStatement(rows, new Set(q.map(itemKey)));
  check('listed products are shown separately, the rest are added into the last line', s.lines.length === 1 && s.other.itemCount === 2 && s.other.smallCount === 2);
  check('a product on the list stays on its own line when it is zero in the period', buildStatement([row('A paisa over', 0, 0, 0, 0, 0)], new Set(['a paisa over'])).lines.length === 1);
  check('a negative amount never qualifies (it is no stock in hand)', qualifyingProducts([row('Minus', -2, 0, 0, -2, -9000000)]).length === 0);
}

// ---------------------------------------------------------------- random data: totals must tie
console.log('--- random data: nothing is lost or invented ---');
{
  let seed = 7;
  const rnd = () => ((seed = (seed * 1664525 + 1013904223) % 4294967296) / 4294967296);
  const rows: StockRow[] = [];
  for (let i = 0; i < 600; i++) {
    const name = `Item ${Math.floor(rnd() * 350)}`; // many names repeat: old + new SKUs
    const opening = Math.round((rnd() - 0.25) * 4000) / 2;
    const qtyIn = Math.round(rnd() * 2000) / 2;
    const qtyOut = Math.round(rnd() * 2500) / 2;
    const closing = opening + qtyIn - qtyOut;
    const rate = 50 + rnd() * 5000;
    rows.push(row(name, opening, qtyIn, qtyOut, closing, Math.round(closing * rate * (rnd() < 0.15 ? -1 : 1) * 100) / 100));
  }
  const list = new Set(qualifyingProducts(rows).map((x) => x.key));
  const s = buildStatement(rows, list, () => 'Nos');
  check('Opening, In, Out and Closing STOCK totals equal Zoho\'s exactly', s.quantitiesTie, `${s.total.closing} vs ${s.zoho.closing}`);
  check('Opening + In - Out = Closing on every line and in the Grand Total', [...s.lines, s.other].every((l) => near(l.opening + l.qtyIn - l.qtyOut, l.closing, 0.002)) && near(s.total.opening + s.total.qtyIn - s.total.qtyOut, s.total.closing, 0.01));
  const explained = s.adjustments.reduce((t, a) => t + (a.usedValue - a.zohoValue), 0);
  check('the amount difference to Zoho is fully explained by the adjusted products', near(explained, s.valueDifference, 0.05), `${explained.toFixed(2)} vs ${s.valueDifference}`);
  check('no separately shown line is negative-stock', s.lines.every((l) => l.opening >= 0 && l.closing >= 0));
  check('lines are in A-Z order', s.lines.every((l, i) => i === 0 || s.lines[i - 1].name.localeCompare(l.name, 'en', { sensitivity: 'base' }) <= 0));
  const mustBeSeparate = s.qualifying.filter((q) => {
    const rs = rows.filter((r) => itemKey(r.name) === q.key);
    const op = rs.reduce((t, r) => t + r.opening, 0);
    const cl = rs.reduce((t, r) => t + r.closing, 0);
    return op >= 0 && cl >= 0;
  });
  check('every over-5-lakh product whose stock is not negative is on its own line', mustBeSeparate.length > 0 && mustBeSeparate.every((q) => s.lines.some((l) => l.key === q.key)), `${mustBeSeparate.length} products`);
}

// ---------------------------------------------------------------- dates
console.log('--- dates on this tab ---');
{
  const today = '2026-10-13';
  check('the tab starts on 1 Apr 2026', STOCK_FIRST_DATE === '2026-04-01');
  const m = stockMonthOptions(today);
  check('months: Oct (to date) down to Apr 2026, nothing earlier', m.length === 7 && m[0].label === 'October 2026 (to date)' && m[0].from === '2026-10-01' && m[0].to === today && m[6].from === '2026-04-01', m.map((x) => x.label).join(' | '));
  check('a finished month runs from its 1st to its last day', m[1].label === 'September 2026' && m[1].from === '2026-09-01' && m[1].to === '2026-09-30' && m[5].to === '2026-05-31');
  const q = stockQuarterOptions(today);
  check('quarters: Q3 FY27 (to date), Q2, Q1', q.map((x) => x.label).join('|') === 'Q3 FY27 (to date)|Q2 FY27|Q1 FY27' && q[2].from === '2026-04-01' && q[2].to === '2026-06-30' && q[0].to === today);
  const y = stockYearOptions(today);
  check('year: FY27 (to date) = 1 Apr 2026 to today', y.length === 1 && y[0].label === 'FY27 (to date)' && y[0].from === '2026-04-01' && y[0].to === today);
  check('the tab opens on FY27 to date', defaultStockRange(today).from === '2026-04-01' && defaultStockRange(today).to === today);
  check('a year that has ended runs to 31 March', stockYearOptions('2027-05-10').map((o) => `${o.label} ${o.from} ${o.to}`).join('|') === 'FY28 (to date) 2027-04-01 2027-05-10|FY27 2026-04-01 2027-03-31');
  check('Jan-Mar belongs to the year that started the April before', fyStartYearOf('2027-02-14') === 2026 && fyStartYearOf('2026-04-01') === 2026 && fyStartYearOf('2026-03-31') === 2025);
  const c1 = clampStockRange('2025-12-01', '2026-02-10', today);
  check('FY26 or earlier is moved up to 1 Apr 2026', c1.from === '2026-04-01' && c1.to === '2026-04-01' && c1.changed);
  const c2 = clampStockRange('2026-09-30', '2026-09-01', today);
  check('From after To is pulled back to To', c2.from === c2.to && c2.changed);
  const c3 = clampStockRange('2026-05-01', '2027-01-01', today);
  check('a To in the future is held at today', c3.to === today && c3.from === '2026-05-01');
  const c4 = clampStockRange('2026-05-01', '2026-05-31', today);
  check('a good range is left alone', c4.from === '2026-05-01' && c4.to === '2026-05-31' && !c4.changed);
  const c5 = clampStockRange(undefined, 'rubbish', today);
  check('nothing / rubbish gives the default range', c5.from === '2026-04-01' && c5.to === today);
}

console.log(failures === 0 ? '\nALL STOCK SELF-TESTS PASSED' : `\n${failures} CHECK(S) FAILED`);
process.exit(failures ? 1 : 0);
